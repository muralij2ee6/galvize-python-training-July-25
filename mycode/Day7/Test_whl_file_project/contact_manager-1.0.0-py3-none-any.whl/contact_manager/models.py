import re
from datetime import datetime
from typing import Dict, Optional


class Contact:
    def __init__(self, name: str, phone: str, email: str,
                 notes: str = "", category: str = "Other"):
        self.name = name
        self.phone = phone
        self.email = email
        self.notes = notes
        self.category = category
        self.created_at = datetime.now()
        self.updated_at = self.created_at

    def update(self, **kwargs):
        """Update contact attributes"""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
        self.updated_at = datetime.now()

    def validate(self) -> bool:
        """Validate email and phone format"""
        email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        phone_regex = r'^\+?[0-9]{10,15}$'
        return (re.match(email_regex, self.email) is not None and
                re.match(phone_regex, self.phone) is not None)

    def to_dict(self) -> Dict:
        """Convert contact to dictionary"""
        return {
            'name': self.name,
            'phone': self.phone,
            'email': self.email,
            'notes': self.notes,
            'category': self.category,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

    def __str__(self) -> str:
        """String representation of contact"""
        return (f"Name: {self.name}\n"
                f"Phone: {self.phone}\n"
                f"Email: {self.email}\n"
                f"Category: {self.category}\n"
                f"Notes: {self.notes}\n"
                f"Last Updated: {self.updated_at.strftime('%Y-%m-%d %H:%M')}")