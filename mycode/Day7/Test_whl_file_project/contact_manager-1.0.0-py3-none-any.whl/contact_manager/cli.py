from typing import Optional, List
from manager import ContactManager
from models import Contact


class ContactCLI:
    def __init__(self):
        self.manager = ContactManager()

    def run(self):
        while True:
            print("\nContact Management System")
            print("1. Add Contact")
            print("2. Search Contacts")
            print("3. Edit Contact")
            print("4. Delete Contact")
            print("5. View All Contacts")
            print("6. Export Contacts")
            print("7. Exit")

            choice = input("Enter your choice (1-7): ")

            if choice == "1":
                self._add_contact()
            elif choice == "2":
                self._search_contacts()
            elif choice == "3":
                self._edit_contact()
            elif choice == "4":
                self._delete_contact()
            elif choice == "5":
                self._view_all_contacts()
            elif choice == "6":
                self._export_contacts()
            elif choice == "7":
                print("Goodbye!")
                break
            else:
                print("Invalid choice. Please try again.")

    def _add_contact(self):
        print("\nAdd New Contact")
        name = self._get_input("Name: ", required=True)
        phone = self._get_input("Phone: ", required=True)
        email = self._get_input("Email: ", required=True)
        notes = self._get_input("Notes: ")
        print("Categories:", ", ".join(self.manager.DEFAULT_CATEGORIES))
        category = self._get_input("Category: ",
                                 default="Other",
                                 options=self.manager.DEFAULT_CATEGORIES)

        contact = Contact(name, phone, email, notes, category)
        print(self.manager.add_contact(contact))

    def _search_contacts(self):
        term = input("\nEnter search term: ").strip()
        if not term:
            print("Please enter a search term")
            return

        results = self.manager.search_contacts(term)
        print(f"\nFound {len(results)} contacts:")
        for contact in results:
            print("\n" + str(contact))

    def _edit_contact(self):
        name_to_search  = input("\nEnter name of contact to edit: ")
        print("Leave field blank to keep current value")
        updates = {
            'name': self._get_input("New Name: "),
            'phone': self._get_input("New Phone: "),
            'email': self._get_input("New Email: "),
            'notes': self._get_input("New Notes: "),
            'category': self._get_input("New Category: ",
                                      options=self.manager.DEFAULT_CATEGORIES)
        }
        # Remove empty updates
        updates = {k: v for k, v in updates.items() if v}
        print(self.manager.edit_contact(name_to_search , **updates))

    def _delete_contact(self):
        delete_name = input("\nEnter name of contact to delete: ")
        print(self.manager.delete_contact(delete_name))

    def _view_all_contacts(self):
        print("\nAll Contacts:")
        print(self.manager.display_all_contacts())

    def _export_contacts(self):
        filename = input("\nEnter filename to export (default: contacts.txt): ")
        filename = filename or "contacts.txt"
        print(self.manager.export_to_file(filename))

    def _get_input(self, prompt: str,
                  required: bool = False,
                  default: Optional[str] = None,
                  options: Optional[List[str]] = None) -> str:
        """Helper method to get validated user input"""
        while True:
            value = input(prompt).strip()
            if not value:
                if default is not None:
                    return default
                if not required:
                    return ""
                print("This field is required")
                continue
            if options and value not in options:
                print(f"Must be one of: {', '.join(options)}")
                continue
            return value


def main():
    cli = ContactCLI()
    cli.run()


if __name__ == "__main__":
    main()