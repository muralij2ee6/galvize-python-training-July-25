import json
from typing import Optional, List
from pathlib import Path
from models import Contact


class ContactManager:
    DEFAULT_CATEGORIES = ["Family", "Work", "Friends", "Other"]

    def __init__(self, storage_file: str = "contacts.json"):
        self.contacts: List[Contact] = []
        self.storage_file = storage_file
        self.load_contacts()

    def add_contact(self, contact: Contact) -> str:
        """Add a new contact with validation"""
        if not contact.validate():
            return "Invalid email or phone format"
        if self._is_duplicate(contact):
            return "Duplicate contact detected"
        self.contacts.append(contact)
        self.save_contacts()
        return "Contact added successfully"

    def _is_duplicate(self, contact: Contact) -> bool:
        """Check for existing contacts with same email or phone"""
        return any(
            c.email.lower() == contact.email.lower() or
            c.phone == contact.phone
            for c in self.contacts
        )

    def search_contacts(self, term: str) -> List[Contact]:
        """Search contacts by any field"""
        term = term.lower()
        return [
            c for c in self.contacts
            if (term in c.name.lower() or
                term in c.phone or
                term in c.email.lower() or
                term in c.notes.lower() or
                term in c.category.lower())
        ]

    def edit_contact(self, old_email: str, **kwargs) -> str:
        """Update contact details"""
        for contact in self.contacts:
            if contact.email.lower() == old_email.lower():
                contact.update(**kwargs)
                self.save_contacts()
                return "Contact updated successfully"
        return "Contact not found"

    def delete_contact(self, delete_name: str) -> str:
        """Remove contact by email"""
        self.contacts = [c for c in self.contacts
                         if c.name.lower() != delete_name.lower()]
        changed = len(self.contacts) != len(self.save_contacts())
        return "Contact deleted successfully" if changed else "Contact not found"

    def get_by_category(self, category: str) -> List[Contact]:
        """Get contacts by category"""
        return [c for c in self.contacts
                if c.category.lower() == category.lower()]

    def save_contacts(self) -> List[Contact]:
        """Persist contacts to storage"""
        with open(self.storage_file, 'w') as f:
            json.dump([c.to_dict() for c in self.contacts], f, indent=2)
        return self.contacts

    def load_contacts(self) -> List[Contact]:
        """Load contacts from storage"""
        try:
            with open(self.storage_file, 'r') as f:
                data = json.load(f)
                self.contacts = [
                    Contact(
                        name=item['name'],
                        phone=item['phone'],
                        email=item['email'],
                        notes=item.get('notes', ''),
                        category=item.get('category', 'Other')
                    ) for item in data
                ]
        except (FileNotFoundError, json.JSONDecodeError):
            self.contacts = []
        return self.contacts

    def export_to_file(self, filename: str) -> str:
        """Export contacts to text file"""
        try:
            with open(filename, 'w') as f:
                f.write(self.display_all_contacts())
            return f"Contacts exported to {filename}"
        except IOError as e:
            return f"Export failed: {str(e)}"

    def display_all_contacts(self) -> str:
        """Format all contacts for display"""
        if not self.contacts:
            return "No contacts found"

        output = []
        for category in self.DEFAULT_CATEGORIES:
            contacts = self.get_by_category(category)
            if contacts:
                output.append(f"\n=== {category.upper()} ===")
                output.extend(str(c) for c in contacts)
        return "\n".join(output)